using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication2.Views.Home
{
    public class contactModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
