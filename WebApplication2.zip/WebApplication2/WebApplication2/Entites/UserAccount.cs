﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication2.Entites
{
    public class UserAccount
    {
        [Key]
        public int ID { get; set; }
        [Required(ErrorMessage = "Enter name!!!")]
        [MaxLength(30, ErrorMessage = "Max len is 30 ")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Password!!!")]
        //[DataType(DataType.Password)]
        public string Password { get; set; }
        [Required(ErrorMessage = "Enter Email!!!")]
        [MaxLength(100, ErrorMessage = "Max len is 100 ")]

        public string Email { get; set; }

        [Required(ErrorMessage = "Enter Birth!!!")]
        public DateOnly Birth { get; set; }

        [Required(ErrorMessage = "Enter Address!!!")]
        //[DataType(DataType.EmailAddress)]
        public string Address { get; set; }
        [Required(ErrorMessage = "Enter phone!!!")]
        public string Phone { get; set; }
        [Required(ErrorMessage = "Enter gender!!!")]
        public string Gender { get; set; }

    }
}

//Std_ID VARCHAR(50) PRIMARY KEY,
//    Prof_ID VARCHAR(50),
//    Dept_ID VARCHAR(50),
//    Name VARCHAR(100),
//    Email VARCHAR(100),
//    GPA FLOAT,
//    Attendance FLOAT,
//    DateOfBirth DATE,
//    Age INT,
//    Address VARCHAR(200),
//    Phone VARCHAR(20),
//    Gender VARCHAR(10),